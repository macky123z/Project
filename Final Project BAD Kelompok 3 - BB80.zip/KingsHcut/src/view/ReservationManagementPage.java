package view;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import main.DatabaseConnect;
import model.ReservationHeader;

public class ReservationManagementPage extends Application{
	Scene scene;
    GridPane gp;
    Label lblReservationManagement, lblReservationListTitle;
    Label lblId, lblDate, lblStartTime, lblEndTime, lblStatus;
    Button btnCancel, btnComplete;
    TableView<ReservationHeader> table;
    Vector<ReservationHeader> reservationData;

    
    String username;

    public ReservationManagementPage(String username) {
        this.username = username;
    }

	public ReservationManagementPage() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		initialize();
        layout();

        primaryStage.setTitle("Reservation Management");
        primaryStage.setScene(scene);
        primaryStage.show();
		
	}

	private void initialize() {
		// TODO Auto-generated method stub
		lblReservationManagement = new Label("Reservation Management");
		lblReservationManagement.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        lblReservationListTitle = new Label("Reservation List");
        lblReservationListTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        lblId = new Label("ID: ");
        lblDate = new Label("Date: ");
        lblStartTime = new Label("Start Time: ");
        lblEndTime = new Label("End Time: ");
        lblStatus = new Label("Status: ");
        
        btnCancel = new Button("Cancel");
        btnCancel.setOnAction(event -> handleCancelReservation());
        
        btnComplete = new Button("Complete");
        btnComplete.setOnAction(event -> handleCompleteReservation());
        
        table = new TableView<>();

        TableColumn<ReservationHeader, String> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("reservationID"));
        idColumn.setPrefWidth(80);

        TableColumn<ReservationHeader, String> dateColumn = new TableColumn<>("Date");
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("reservationDate"));
        dateColumn.setPrefWidth(100);

        TableColumn<ReservationHeader, String> startTimeColumn = new TableColumn<>("Start Time");
        startTimeColumn.setCellValueFactory(new PropertyValueFactory<>("startReservationTime"));
        startTimeColumn.setPrefWidth(120);

        TableColumn<ReservationHeader, String> endTimeColumn = new TableColumn<>("End Time");
        endTimeColumn.setCellValueFactory(new PropertyValueFactory<>("endReservationTime"));
        endTimeColumn.setPrefWidth(120);

        TableColumn<ReservationHeader, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("reservationStatus"));
        statusColumn.setPrefWidth(100);

        table.getColumns().addAll(idColumn, dateColumn, startTimeColumn, endTimeColumn, statusColumn);
        
        table.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);

        // Add listener for row selection
        table.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> updateReservationDetails(newValue));

        loadReservationData();
        populateTableView();

		
	}

	private void layout() {
		// TODO Auto-generated method stub
		
		GridPane gp = new GridPane();
        gp.setPadding(new Insets(0)); 
        gp.setHgap(10);
        gp.setVgap(10);

        // User Navigation Bar
        MenuBar userMenu = new AdminNavigationBar(username).getMenuBar();
        userMenu.setPrefWidth(Double.MAX_VALUE);
        gp.add(userMenu, 0, 0, 2, 1);

        
        GridPane.setHgrow(userMenu, Priority.ALWAYS);

        
        
        gp.add(lblReservationManagement, 0, 1);
        gp.add(lblReservationListTitle, 0, 2);

        
        gp.add(table, 0, 3);

        
        VBox vboxDetails = new VBox(10, lblId, lblDate, lblStartTime, lblEndTime, lblStatus, btnCancel, btnComplete);
        vboxDetails.setPadding(new Insets(10));
        gp.add(vboxDetails, 1, 3);
        
       
        btnCancel.setPrefWidth(250);
        btnComplete.setPrefWidth(250);
        
       
        scene = new Scene(gp, 800, 500);
		
	}
	
	//method kalo mencet tombol cancel dan validasinya
	private void handleCancelReservation() {
        ReservationHeader selectedReservation = table.getSelectionModel().getSelectedItem();
        if (selectedReservation == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a reservation to cancel.");
            return;
        }

        if (selectedReservation.getReservationStatus().equalsIgnoreCase("Finished")) {
            showAlert(Alert.AlertType.ERROR, "Error", "Cannot cancel finished reservation.");
            return;
        }
        
        if (selectedReservation.getReservationStatus().equalsIgnoreCase("Cancelled")) {
            showAlert(Alert.AlertType.ERROR, "Error", "Reservation is already cancelled.");
            return;
        }

        String reservationID = selectedReservation.getReservationID();
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to connect to the database.");
                return;
            }

            String updateQuery = "UPDATE reservationheader SET ReservationStatus = 'Cancelled' WHERE ReservationID = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
                stmt.setString(1, reservationID);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    selectedReservation.setReservationStatus("Cancelled");
                    table.refresh();
                    showAlert(Alert.AlertType.INFORMATION, "Cancellation Success", "You have successfully cancelled reservation ID: " + reservationID);
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to cancel the reservation.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while canceling the reservation.");
        }
    }
	
	//method kalo mencet tombol complete dan validasinya
	private void handleCompleteReservation() {
        ReservationHeader selectedReservation = table.getSelectionModel().getSelectedItem();
        if (selectedReservation == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a reservation to complete.");
            return;
        }

        
        if (selectedReservation.getReservationStatus().equalsIgnoreCase("Cancelled")) {
            showAlert(Alert.AlertType.ERROR, "Error", "Cannot Complete cancelled reservation.");
            return;
        }
        
        if (selectedReservation.getReservationStatus().equalsIgnoreCase("Finished")) {
            showAlert(Alert.AlertType.ERROR, "Error", "Cannot complete finished reservation.");
            return;
        }
        

        String reservationID = selectedReservation.getReservationID();
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to connect to the database.");
                return;
            }

            String updateQuery = "UPDATE reservationheader SET ReservationStatus = 'Finished' WHERE ReservationID = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
                stmt.setString(1, reservationID);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    selectedReservation.setReservationStatus("Finished");
                    table.refresh();
                    showAlert(Alert.AlertType.INFORMATION, "Completion Success", "\"You have successfully completed reservation ID: " + reservationID);
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to finished the reservation.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while canceling the reservation.");
        }
    }
	
	//nge update reservation detail
	private void updateReservationDetails(ReservationHeader reservation) {
        if (reservation != null) {
            lblId.setText("ID: " + reservation.getReservationID());
            lblDate.setText("Date: " + reservation.getReservationDate());
            lblStartTime.setText("Start Time: " + reservation.getStartReservationTime());
            lblEndTime.setText("End Time: " + reservation.getEndReservationTime());
            lblStatus.setText("Status: " + reservation.getReservationStatus());
        } else {
            lblId.setText("ID: ");
            lblDate.setText("Date: ");
            lblStartTime.setText("Start Time: ");
            lblEndTime.setText("End Time: ");
            lblStatus.setText("Status: ");
        }
    }
	
	//ngeload reservation data dari tabel database
    private void loadReservationData() {
    	reservationData = new Vector<>();
    	try (Connection conn = DatabaseConnect.getConnection()) {
    	    String query = "SELECT ReservationID, ReservationDate, StartReservationTime, EndReservationTime, ReservationStatus FROM reservationheader";
    	    PreparedStatement stmt = conn.prepareStatement(query);
    	    ResultSet rs = stmt.executeQuery();

    	    while (rs.next()) {
    	        String id = rs.getString("ReservationID");
    	        Date date = rs.getDate("ReservationDate");
    	        String startTime = rs.getString("StartReservationTime");
    	        String endTime = rs.getString("EndReservationTime");
    	        String status = rs.getString("ReservationStatus");

    	        reservationData.add(new ReservationHeader(id, date.toString(), startTime, endTime, status));
    	    }
    	} catch (SQLException e) {
    	    e.printStackTrace();
    	    showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to load reservation data.");
    	}

    }

    private void populateTableView() {
        table.getItems().clear();
        table.getItems().addAll(reservationData);
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
