package view;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Service;
import main.DatabaseConnect;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Vector;

public class ReserveServicePage extends Application {

    Scene scene;
    BorderPane root;
    GridPane gp;
    TableView<Service> table;
    Vector<Service> serviceData;

    
    Label lblReserveService, lblUserName, lblReserveList, lblReservationDate, lblReservationTime;
    TextField tfReservationTime;
    DatePicker dpReservationDate;
    Button btnAdd, btnCancel, btnReserve;
    ListView<String> reserveList;
    CheckBox cbHaircut, cbPerm, cbColoring, cbTreatment, cbTattoo;

    String username;
    
    //biar nama user yg lagi login bisa di display
    public ReserveServicePage(String username) {
        this.username = username;
    }
    
    ////////////////////
    private void filterTableByCheckBox() {
        table.getItems().clear(); 
        
        for (Service service : serviceData) {
            boolean matches = false;

            
            if (cbHaircut.isSelected() && service.getServiceName().contains("Haircut")) matches = true;
            if (cbPerm.isSelected() && service.getServiceName().contains("Perm")) matches = true;
            if (cbColoring.isSelected() && service.getServiceName().contains("Color")) matches = true;
            if (cbTreatment.isSelected() && service.getServiceName().contains("Treatment")) matches = true;
            if (cbTattoo.isSelected() && service.getServiceName().contains("Tattoo")) matches = true;

            // masukin service ke tabel
            if (matches) {
                table.getItems().add(service);
            }
        }

        
        // kalo gada checkbox yg di centang, tampilin semua service
        if (!cbHaircut.isSelected() && !cbPerm.isSelected() && !cbColoring.isSelected() && 
            !cbTreatment.isSelected() && !cbTattoo.isSelected()) {
            table.getItems().addAll(serviceData);
        }
    }

    
    @Override
    public void start(Stage primaryStage) throws Exception {
        initialize();
        layout();

        primaryStage.setTitle("Reserve Service");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void initialize() {
        lblReserveService = new Label("Reserve Service");
        lblReserveService.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        lblUserName = new Label("User: " + username);

        lblReserveList = new Label("Reserve List");

        lblReservationDate = new Label("Reservation Date");
        lblReservationTime = new Label("Reservation Time");

        tfReservationTime = new TextField();
        tfReservationTime.setPromptText("hh:mm");

        dpReservationDate = new DatePicker();

        btnAdd = new Button("Add");
        btnCancel = new Button("Cancel");
        btnReserve = new Button("Reserve");

        cbHaircut = new CheckBox("Haircut");
        cbHaircut.setOnAction(event -> filterTableByCheckBox());

        cbPerm = new CheckBox("Perm");
        cbPerm.setOnAction(event -> filterTableByCheckBox());

        cbColoring = new CheckBox("Coloring");
        cbColoring.setOnAction(event -> filterTableByCheckBox());

        cbTreatment = new CheckBox("Hair Treatment");
        cbTreatment.setOnAction(event -> filterTableByCheckBox());

        cbTattoo = new CheckBox("Hair Tattoo");
        cbTattoo.setOnAction(event -> filterTableByCheckBox());


        reserveList = new ListView<>();

        table = new TableView<>();
        TableColumn<Service, String> serviceIdColumn = new TableColumn<>("ID");
        serviceIdColumn.setCellValueFactory(new PropertyValueFactory<>("serviceId"));
        
        
        TableColumn<Service, String> serviceNameColumn = new TableColumn<>("Name");
        serviceNameColumn.setCellValueFactory(new PropertyValueFactory<>("serviceName"));
       
        
        TableColumn<Service, Double> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        
        
        TableColumn<Service, Integer> durationColumn = new TableColumn<>("Duration");
        durationColumn.setCellValueFactory(new PropertyValueFactory<>("duration"));
        
        
        table.getColumns().addAll(serviceIdColumn, serviceNameColumn, priceColumn, durationColumn);

        btnAdd.setOnAction(event -> handleAddButton());
        btnCancel.setOnAction(event -> handleCancelButton());
        btnReserve.setOnAction(event -> handleReserveButton());

        loadServiceData();
        populateTableView();
    }

    private void layout() {
        gp = new GridPane();
        gp.setAlignment(Pos.TOP_LEFT);
        gp.setPadding(new Insets(20));
        gp.setHgap(10);
        gp.setVgap(10);

        gp.add(lblReserveService, 0, 0);
        gp.add(lblUserName, 0, 1);

        HBox hboxCheckboxes = new HBox(10);
        hboxCheckboxes.getChildren().addAll(cbHaircut, cbPerm, cbColoring, cbTreatment, cbTattoo);
        gp.add(hboxCheckboxes, 0, 3);

        gp.add(table, 0, 4, 1, 9);

        gp.add(lblReserveList, 1, 3);
        gp.add(reserveList, 1, 4, 18, 4);

        gp.add(lblReservationDate, 1, 8);
        gp.add(dpReservationDate, 1, 9, 4, 1);

        gp.add(lblReservationTime, 1, 10);
        gp.add(tfReservationTime, 1, 11);

        HBox hboxButtons = new HBox(10);
        hboxButtons.getChildren().addAll(btnAdd, btnCancel, btnReserve);
        gp.add(hboxButtons, 1, 12);

        UserNavigationBar userNav = new UserNavigationBar(username);
        root = new BorderPane();
        root.setTop(userNav.getMenuBar());
        root.setCenter(gp);

        scene = new Scene(root, 800, 500);
    }

    //method kalo mencet tombol add
    private void handleAddButton() {
        // Pastikan ada baris yang dipilih di tabel
        Service selectedService = table.getSelectionModel().getSelectedItem();
        if (selectedService == null) {
            showAlert(Alert.AlertType.ERROR, "Error Reservation", "There is no service selected.");
            return;
        }

        // Cek apakah reservasi sudah ada di list
        if (reserveList.getItems().contains(selectedService.getServiceName())) {
            showAlert(Alert.AlertType.WARNING, "Duplicate Service", "Service is already in the reserve list.");
            return;
        }

        // Validasi tanggal reservasi
        LocalDate selectedDate = dpReservationDate.getValue();
        if (selectedDate == null || selectedDate.isBefore(LocalDate.now())) {
            showAlert(Alert.AlertType.ERROR, "Error Reservation", "Reservation Date cannot be empty or before today.");
            return;
        }

        // Validasi waktu reservasi
        String reservationTime = tfReservationTime.getText().trim();
        if (reservationTime.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Reservation time must be filled.");
            return;
        }

        if (!isValidTimeFormat(reservationTime)) {
            showAlert(Alert.AlertType.ERROR, "Error Reservation", "Invalid time format");
            return;
        }

        String[] timeParts = reservationTime.split(":");
        int hour = Integer.parseInt(timeParts[0]);
        if (hour < 9 || hour > 21) {
            showAlert(Alert.AlertType.ERROR, "Error Reservation", "Reservation Time must be between 09:00 and 21:00.");
            return;
        }

        // Tambahkan nama service ke reserve list
        reserveList.getItems().add(selectedService.getServiceName());

        // Disable input tanggal dan waktu setelah tambah
        tfReservationTime.setDisable(true);
        dpReservationDate.setDisable(true);

        resetFields(true, false);

        showAlert(Alert.AlertType.INFORMATION, "Service Added", "Service successfully added.");
    }

        
  



    
    private boolean isValidTimeFormat(String time) {
        
        return time.matches("([01]\\d|2[0-3]):[0-5]\\d");
    }
    
    //buat nge reset semua yg udh di isi
    private void resetFields(boolean resetCheckboxes, boolean resetAll) {
        if (resetCheckboxes) {
            cbHaircut.setSelected(false);
            cbPerm.setSelected(false);
            cbColoring.setSelected(false);
            cbTreatment.setSelected(false);
            cbTattoo.setSelected(false);
        }

        if (resetAll) {
            tfReservationTime.clear();
            dpReservationDate.setValue(null);
            reserveList.getItems().clear();
            tfReservationTime.setDisable(false);
            dpReservationDate.setDisable(false);
        }
    }

 
    //method kalo mencet tombol cancel
    private void handleCancelButton() {
    	if (reserveList.getItems().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Cancellation Error", "No service selected");
            return;
        }
    	
        reserveList.getItems().clear();
        dpReservationDate.setValue(null);
        tfReservationTime.clear();
        resetFields(true, true);
        showAlert(Alert.AlertType.INFORMATION, "Cancellation Success", "Service successfully cancelled");
    }
    
    //method kalo mencet tombol reserve
    private void handleReserveButton() {
        if (reserveList.getItems().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Reservation Error", "Reserve list cannot be empty.");
            return;
        }

        if (dpReservationDate.getValue() == null || tfReservationTime.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Reservation Date and Reservation Time cannot be empty.");
            return;
        }

        if (!tfReservationTime.getText().matches("\\d{2}:\\d{2}")) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Reservation Time must be in format hh:mm.");
            return;
        }

        LocalDate selectedDate = dpReservationDate.getValue();
        if (selectedDate == null || selectedDate.isBefore(LocalDate.now())) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Reservation Date cannot be empty or before today.");
            return;
        }
        
        String[] timeParts = tfReservationTime.getText().split(":");
        int hour = Integer.parseInt(timeParts[0]);
        if (hour < 9 || hour > 21) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Reservation Time must be between 09:00 and 21:00.");
            return;
        }
        
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Reserve Confirmation Pop-Up");

        Label confirmationLabel = new Label("Are you sure you want to reserve?");
        confirmationLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Button btnYes = new Button("Yes");
        Button btnNo = new Button("No");
        
        //method kalo pop up confirmation di pencet yes
        btnYes.setOnAction(e -> {
            try (Connection connection = DatabaseConnect.getConnection()) {
                if (connection == null) {
                    showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to connect to the database.");
                    return;
                }

                String userID = getUserIdByUsername(connection, username);
                if (userID == null) {
                    showAlert(Alert.AlertType.ERROR, "User Error", "UserID not found in the database.");
                    return;
                }

                String reservationID = generateReservationID(connection);

                String startTime = tfReservationTime.getText();
                int totalDuration = calculateTotalDuration();
                String endTime = calculateEndTime(startTime, totalDuration);

                String insertHeaderQuery = "INSERT INTO reservationheader (ReservationID, UserID, ReservationDate, StartReservationTime, EndReservationTime, ReservationStatus) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement headerStmt = connection.prepareStatement(insertHeaderQuery)) {
                    headerStmt.setString(1, reservationID);
                    headerStmt.setString(2, userID);
                    headerStmt.setDate(3, Date.valueOf(dpReservationDate.getValue()));
                    headerStmt.setString(4, startTime);
                    headerStmt.setString(5, endTime);
                    headerStmt.setString(6, "In Progress");
                    headerStmt.executeUpdate();
                }

                String insertDetailQuery = "INSERT INTO reservationdetail (ReservationID, ServiceID) VALUES (?, ?)";
                try (PreparedStatement detailStmt = connection.prepareStatement(insertDetailQuery)) {
                    for (String serviceName : reserveList.getItems()) {
                        String serviceID = getServiceIdByName(serviceName);
                        if (serviceID != null) {
                            detailStmt.setString(1, reservationID);
                            detailStmt.setString(2, serviceID);
                            detailStmt.addBatch();
                        }
                    }
                    detailStmt.executeBatch();
                }
                
                resetFields(true, true);
                reserveList.getItems().clear();
                showAlert(Alert.AlertType.INFORMATION, "Reservation Successful", "Reservation successfully reserved");
              
                
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to reserve. Please try again later.");
            }

            popupStage.close();
        });
        //method kalo pop up confirmation di pencet no
        btnNo.setOnAction(e -> popupStage.close());

        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);
        
        layout.getChildren().addAll(confirmationLabel, new HBox(10, btnYes, btnNo));

        Scene popupScene = new Scene(layout, 400, 200);
        popupStage.setScene(popupScene);
        popupStage.showAndWait();
    }

    private String getUserIdByUsername(Connection connection, String username) {
        String query = "SELECT UserID FROM msuser WHERE Username = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("UserID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    //buat bikin reservation id biar pas sama validasi di database
    private String generateReservationID(Connection connection) throws SQLException {
        String query = "SELECT COUNT(*) AS count FROM reservationheader";
        PreparedStatement stmt = connection.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        int count = 0;
        if (rs.next()) {
            count = rs.getInt("count");
        }
        return String.format("RS%03d", count + 1);
    }
    
    //ngitung durasi service nya
    private int calculateTotalDuration() {
        int totalDuration = 0;
        for (String serviceName : reserveList.getItems()) {
            for (Service service : serviceData) {
                if (service.getServiceName().equals(serviceName)) {
                    totalDuration += service.getDuration();
                }
            }
        }
        return totalDuration;
    }
    
    //ngitung kapan kelar dari suatu service
    private String calculateEndTime(String startTime, int totalDuration) {
        String[] timeParts = startTime.split(":");
        int hour = Integer.parseInt(timeParts[0]);
        int minute = Integer.parseInt(timeParts[1]);

        minute += totalDuration;
        hour += minute / 60;
        minute %= 60;

        return String.format("%02d:%02d", hour, minute);
    }

    private String getServiceIdByName(String serviceName) {
        for (Service service : serviceData) {
            if (service.getServiceName().equals(serviceName)) {
                return service.getServiceId();
            }
        }
        return null;
    }
    
    //nge load data buat tabel
    private void loadServiceData() {
        serviceData = new Vector<>();
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn != null) {
                String query = "SELECT ServiceID, ServiceName, ServicePrice, ServiceDuration FROM msservice";
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    String id = rs.getString("ServiceID");
                    String name = rs.getString("ServiceName");
                    double price = rs.getDouble("ServicePrice");
                    int duration = rs.getInt("ServiceDuration");

                    serviceData.add(new Service(id, name, price, duration));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void populateTableView() {
        table.getItems().clear();
        table.getItems().addAll(serviceData);
        filterTableByCheckBox(); 
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}