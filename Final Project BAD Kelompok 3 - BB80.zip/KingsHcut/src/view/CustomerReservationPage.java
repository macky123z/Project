package view;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import main.DatabaseConnect;
import model.ReservationHeader;

public class CustomerReservationPage extends Application {

    Scene scene;
    GridPane gp;
    Label lblUsername, lblReservationHistoryTitle;
    Label lblId, lblDate, lblStartTime, lblEndTime, lblStatus;
    Button btnCancel;
    TableView<ReservationHeader> table;
    Vector<ReservationHeader> reservationData;

    String username;
    
    //biar username yg log in bisa di display
    public CustomerReservationPage(String username) {
        this.username = username;
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        initialize();
        layout();

        primaryStage.setTitle("Customer Reservation");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void initialize() {
        lblUsername = new Label(username + "'s Reservation");
        lblUsername.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        lblReservationHistoryTitle = new Label("Reservation History");
        lblReservationHistoryTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        lblId = new Label("ID: ");
        lblDate = new Label("Date: ");
        lblStartTime = new Label("Start Time: ");
        lblEndTime = new Label("End Time: ");
        lblStatus = new Label("Status: ");

        btnCancel = new Button("Cancel");
        btnCancel.setOnAction(event -> handleCancelReservation());

        table = new TableView<>();

        TableColumn<ReservationHeader, String> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("reservationID"));
        idColumn.setPrefWidth(100);

        TableColumn<ReservationHeader, String> dateColumn = new TableColumn<>("Date");
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("reservationDate"));
        dateColumn.setPrefWidth(150);

        TableColumn<ReservationHeader, String> startTimeColumn = new TableColumn<>("Start Time");
        startTimeColumn.setCellValueFactory(new PropertyValueFactory<>("startReservationTime"));
        startTimeColumn.setPrefWidth(120);

        TableColumn<ReservationHeader, String> endTimeColumn = new TableColumn<>("End Time");
        endTimeColumn.setCellValueFactory(new PropertyValueFactory<>("endReservationTime"));
        endTimeColumn.setPrefWidth(120);

        TableColumn<ReservationHeader, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("reservationStatus"));
        statusColumn.setPrefWidth(150);

        table.getColumns().addAll(idColumn, dateColumn, startTimeColumn, endTimeColumn, statusColumn);

        // biar kolom gabisa di resize
        table.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);

        
        table.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> updateReservationDetails(newValue));

        loadReservationData();
        populateTableView();
    }

    private void layout() {
        
        GridPane gp = new GridPane();
        gp.setPadding(new Insets(0)); 
        gp.setHgap(10);
        gp.setVgap(10);

        // User Navigation Bar
        MenuBar userMenu = new UserNavigationBar(username).getMenuBar();
        userMenu.setPrefWidth(Double.MAX_VALUE); 
        gp.add(userMenu, 0, 0, 2, 1);

        
        GridPane.setHgrow(userMenu, Priority.ALWAYS);

        
        Label lblPageTitle = new Label(username + "'s Reservation");
        lblPageTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        gp.add(lblPageTitle, 0, 1);

        Label lblReservationHistoryTitle = new Label("Reservation History");
        lblReservationHistoryTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        gp.add(lblReservationHistoryTitle, 0, 2);

        // tabelnya
        gp.add(table, 0, 3);

        
        VBox vboxDetails = new VBox(10, lblId, lblDate, lblStartTime, lblEndTime, lblStatus, btnCancel);
        vboxDetails.setPadding(new Insets(10));
        gp.add(vboxDetails, 1, 3);

        
        scene = new Scene(gp, 800, 500);
    }


    //method kalo mencet tombol cancel
    private void handleCancelReservation() {
        ReservationHeader selectedReservation = table.getSelectionModel().getSelectedItem();
        if (selectedReservation == null) {
            showAlert(Alert.AlertType.ERROR, "Selection Error", "Please select a reservation to cancel.");
            return;
        }

        if (selectedReservation.getReservationStatus().equals("Finished")) {
            showAlert(Alert.AlertType.ERROR, "Invalid Action", "Cannot cancel finished reservation");
            return;
        }

        if (selectedReservation.getReservationStatus().equals("Cancelled")) {
            showAlert(Alert.AlertType.ERROR, "Invalid Action", "Reservation is already cancelled");
            return;
        }
        
        String reservationID = selectedReservation.getReservationID();
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to connect to the database.");
                return;
            }

            String updateQuery = "UPDATE reservationheader SET ReservationStatus = 'Cancelled' WHERE ReservationID = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
                stmt.setString(1, reservationID);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    selectedReservation.setReservationStatus("Cancelled");
                    table.refresh();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Your Reservation successfully canceled.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to cancel the reservation.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while canceling the reservation.");
        }
    }
    
    //nge update reservation detail
    private void updateReservationDetails(ReservationHeader reservation) {
        if (reservation != null) {
            lblId.setText("ID: " + reservation.getReservationID());
            lblDate.setText("Date: " + reservation.getReservationDate());
            lblStartTime.setText("Start Time: " + reservation.getStartReservationTime());
            lblEndTime.setText("End Time: " + reservation.getEndReservationTime());
            lblStatus.setText("Status: " + reservation.getReservationStatus());
        } else {
            lblId.setText("ID: ");
            lblDate.setText("Date: ");
            lblStartTime.setText("Start Time: ");
            lblEndTime.setText("End Time: ");
            lblStatus.setText("Status: ");
        }
    }
    //method buat ngeload data reservaation ke tabel
    private void loadReservationData() {
        reservationData = new Vector<>();
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn != null) {
                String query = "SELECT ReservationID, ReservationDate, StartReservationTime, EndReservationTime, ReservationStatus FROM reservationheader WHERE UserID = (SELECT UserID FROM msuser WHERE Username = ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, username);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    String id = rs.getString("ReservationID");
                    Date date = rs.getDate("ReservationDate");
                    String startTime = rs.getString("StartReservationTime");
                    String endTime = rs.getString("EndReservationTime");
                    String status = rs.getString("ReservationStatus");

                    reservationData.add(new ReservationHeader(id, date.toString(), startTime, endTime, status));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to load reservation data.");
        }
    }

    private void populateTableView() {
        table.getItems().clear();
        table.getItems().addAll(reservationData);
    }
    
    //template alert
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
