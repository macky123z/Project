package view;

import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import main.Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class AdminNavigationBar {
    private MenuBar menuBar;
    private String username;

    public AdminNavigationBar(String username) {
        this.username = username;
        initialize();
    }

    private void initialize() {
        menuBar = new MenuBar();

        // Menu
        Menu menu = new Menu("Menu");

        // Menu Items
        MenuItem serviceManagement = new MenuItem("Service Management");
        MenuItem reservationManagement = new MenuItem("Reservation Management");
        MenuItem logOut = new MenuItem("Log Out");

        // Event Handler
        serviceManagement.setOnAction(event -> navigateToServiceManagement());
        reservationManagement.setOnAction(event -> navigateToReservationManagement());
        logOut.setOnAction(event -> logOut());

        //masukin menu 
        menu.getItems().addAll(serviceManagement, reservationManagement, logOut);

        // nambahin menu ke menu bar
        menuBar.getMenus().add(menu);
    }

    public MenuBar getMenuBar() {
        return menuBar;
    }
    
    //kalo admin mencet service management di nav bar, dia bakal lari ke Service Management page
    private void navigateToServiceManagement() {
        try {
            ServiceManagementPage serviceManagementPage = new ServiceManagementPage(username, "Admin");
            Stage stage = (Stage) menuBar.getScene().getWindow();
            serviceManagementPage.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //biar kalo admin mencet reservation management di navigation bar, dia bakal lari ke halaman ReservationManagementPage
    private void navigateToReservationManagement() {
        try {
            // Buat instance halaman ReservationManagementPage
            ReservationManagementPage reservationPage = new ReservationManagementPage(username);
            
            
            Stage stage = (Stage) menuBar.getScene().getWindow();
            
            
            reservationPage.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //kalo pencet logout bakal balik ke halaman login
    private void logOut() {
        try {
            Main mainApp = new Main();
            Stage stage = (Stage) menuBar.getScene().getWindow();
            mainApp.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
