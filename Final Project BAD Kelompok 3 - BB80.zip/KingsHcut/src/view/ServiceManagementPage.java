package view;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import main.DatabaseConnect;
import model.ServiceManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class ServiceManagementPage extends Application {

    Scene scene;
    BorderPane root;
    GridPane gp;
    TableView<ServiceManagement> table;
    Vector<ServiceManagement> serviceData;

    
    Label lblServiceManagement, lblServiceList, lblServiceName, lblServiceType, lblServicePrice, lblServiceDuration;
    TextField tfServiceName, tfServicePrice, tfServiceDuration;
    ComboBox<String> cbServiceType;
    Button btnAdd, btnUpdate, btnDelete;
	private String userRole;
	private String username;

    public ServiceManagementPage() {}

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        initialize();
        layout();

        primaryStage.setTitle("Service Management");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void initialize() {
        lblServiceManagement = new Label("Service Management");
        lblServiceManagement.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        lblServiceList = new Label("Service List");
        lblServiceList.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        lblServiceName = new Label("Service Name");
        lblServiceType = new Label("Service Type");
        lblServicePrice = new Label("Service Price");
        lblServiceDuration = new Label("Service Duration");

        tfServiceName = new TextField();
        tfServiceName.setPromptText("Input service name here");

        tfServicePrice = new TextField();
        tfServicePrice.setPromptText("Input service price here");

        tfServiceDuration = new TextField();
        tfServiceDuration.setPromptText("Input service duration here");

        cbServiceType = new ComboBox<>();
        cbServiceType.setPromptText("Select service type");
        populateServiceTypeComboBox();

        btnAdd = new Button("Add");
        btnUpdate = new Button("Update");
        btnDelete = new Button("Delete");

        table = new TableView<>();
        TableColumn<ServiceManagement, String> serviceIdColumn = new TableColumn<>("Service ID");
        serviceIdColumn.setCellValueFactory(new PropertyValueFactory<>("serviceId"));
        serviceIdColumn.setPrefWidth(80);

        TableColumn<ServiceManagement, String> serviceTypeColumn = new TableColumn<>("Service Type");
        serviceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("serviceType"));
        serviceTypeColumn.setPrefWidth(100);

        TableColumn<ServiceManagement, String> serviceNameColumn = new TableColumn<>("Service Name");
        serviceNameColumn.setCellValueFactory(new PropertyValueFactory<>("serviceName"));
        serviceNameColumn.setPrefWidth(150);

        TableColumn<ServiceManagement, Double> servicePriceColumn = new TableColumn<>("Service Price");
        servicePriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        servicePriceColumn.setPrefWidth(150);

        TableColumn<ServiceManagement, Integer> serviceDurationColumn = new TableColumn<>("Service Duration");
        serviceDurationColumn.setCellValueFactory(new PropertyValueFactory<>("duration"));
        serviceDurationColumn.setPrefWidth(100);

        table.getColumns().addAll(serviceIdColumn, serviceTypeColumn, serviceNameColumn, servicePriceColumn, serviceDurationColumn);
        table.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        
        btnAdd.setOnAction(event -> handleAddService());
        btnUpdate.setOnAction(event -> handleUpdateService());
        btnDelete.setOnAction(event -> handleDeleteService());


        
        loadServiceData();
        populateTableView();
        
        //panggil method selected data dari tabel
        table.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                populateFieldsFromSelectedService(newValue);
            }
        });

    }
    
    //method biar kalo mencet service lgsg keluar datanya
    private void populateFieldsFromSelectedService(ServiceManagement selectedService) {
        tfServiceName.setText(selectedService.getServiceName());
        cbServiceType.setValue(selectedService.getServiceType());
        tfServicePrice.setText(String.valueOf(selectedService.getPrice()));
        tfServiceDuration.setText(String.valueOf(selectedService.getDuration()));
    }

    //method kalo mencet delete
    private void handleDeleteService() {
        
        ServiceManagement selectedService = table.getSelectionModel().getSelectedItem();

        
        if (selectedService == null) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Please select a service to delete.");
            return;
        }

        // pop up konfirmasi kalo mau ngehapus
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Delete Confirmation");
        confirmAlert.setHeaderText(null);
        confirmAlert.setContentText("Are you sure you want to delete the selected service?");
        if (confirmAlert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) {
            return; 
        }

        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to connect to database.");
                return;
            }

            
            String query = "DELETE FROM msservice WHERE ServiceID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, selectedService.getServiceId());
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                //refresh data abis diapus
                loadServiceData();
                populateTableView();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Service successfully deleted.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete the service.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to delete service: " + e.getMessage());
        }
    }
    //method kalo misal mencet tombol update
    private void handleUpdateService() {
        // ngecek apakah ada row yang dipilih
        ServiceManagement selectedService = table.getSelectionModel().getSelectedItem();
        if (selectedService == null) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Please select a service to update!");
            return;
        }

        String serviceName = tfServiceName.getText();
        String serviceTypeName = cbServiceType.getValue();
        String serviceTypeID = getServiceTypeID(serviceTypeName); // Ambil ServiceTypeID dari nama
        double price;
        int duration;

        // Validasi
        if (serviceName.isEmpty() || serviceTypeName == null || tfServicePrice.getText().isEmpty() || tfServiceDuration.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields must be filled!");
            return;
        }

        // Validasi harga dan durasi
        try {
            price = Double.parseDouble(tfServicePrice.getText());
            duration = Integer.parseInt(tfServiceDuration.getText());
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Price and duration must be numeric!");
            return;
        }

        // Validasi jika serviceName udh ada (dan bukan nama yang lagi diedit)
        for (ServiceManagement service : serviceData) {
            if (service.getServiceName().equalsIgnoreCase(serviceName) && !service.getServiceId().equals(selectedService.getServiceId())) {
                showAlert(Alert.AlertType.ERROR, "Duplicate Error", "Service name already exists!");
                return;
            }
        }

        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to connect to database.");
                return;
            }

            // update data di database
            String query = "UPDATE msservice SET ServiceTypeID = ?, ServiceName = ?, ServicePrice = ?, ServiceDuration = ? WHERE ServiceID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, serviceTypeID);
            stmt.setString(2, serviceName);
            stmt.setDouble(3, price);
            stmt.setInt(4, duration);
            stmt.setString(5, selectedService.getServiceId());
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                // Refresh data tabel
                loadServiceData();
                populateTableView();
                resetFields();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Service successfully updated!");
            } else {
                showAlert(Alert.AlertType.ERROR, "Update Error", "Failed to update service.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to update service: " + e.getMessage());
        }
    }

    //method kalo mencet tombol add
    private void handleAddService() {
        String serviceName = tfServiceName.getText().trim();
        String serviceType = cbServiceType.getValue();
        String servicePriceText = tfServicePrice.getText().trim();
        String serviceDurationText = tfServiceDuration.getText().trim();
        
        
        if (serviceName.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Service name cannot be empty.");
            return;
        }
        
        // Validasi input kosong
        if (serviceName.isEmpty() || serviceType == null || servicePriceText.isEmpty() || serviceDurationText.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields must be filled.");
            return;
        }

        // Validasi service price dan duration (angka)
        double servicePrice;
        int serviceDuration;
        try {
            servicePrice = Double.parseDouble(servicePriceText);
            serviceDuration = Integer.parseInt(serviceDurationText);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Price and Duration must be valid numbers.");
            return;
        }

        // Validasi apakah service name sudah ada
        if (isServiceNameExist(serviceName)) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Service already exists.");
            return;
        }

        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn != null) {
                // mastiin Service Type ada atau tambahin ke tabel msservicetype
                String serviceTypeID = ensureServiceTypeExists(conn, serviceType);

                // nambahin service ke database
                String query = "INSERT INTO msservice (ServiceID, ServiceTypeID, ServiceName, ServicePrice, ServiceDuration) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, generateServiceID(conn));
                stmt.setString(2, serviceTypeID);
                stmt.setString(3, serviceName);
                stmt.setDouble(4, servicePrice);
                stmt.setInt(5, serviceDuration);

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Service successfully added.");
                    loadServiceData();
                    populateTableView();
                    resetFields();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to add service: " + e.getMessage());
        }
    }
    
    
    //buat ambil service type id
    private String getServiceTypeID(String serviceTypeName) {
        String serviceTypeID = null;
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn != null) {
                String query = "SELECT ServiceTypeID FROM msservicetype WHERE ServiceTypeName = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, serviceTypeName);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    serviceTypeID = rs.getString("ServiceTypeID");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to fetch ServiceTypeID: " + e.getMessage());
        }
        return serviceTypeID;
    }

    
    private String ensureServiceTypeExists(Connection conn, String serviceType) throws SQLException {
        // ngecek apakah Service Type udah ada
        String query = "SELECT ServiceTypeID FROM msservicetype WHERE ServiceTypeName = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, serviceType);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            return rs.getString("ServiceTypeID"); // kalo ada, pake ID yang udah ada
        } else {
            // kalo belom ada, tambahin ke tabel msservicetype
            String newServiceTypeID = generateServiceTypeID(conn);
            String insertQuery = "INSERT INTO msservicetype (ServiceTypeID, ServiceTypeName) VALUES (?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setString(1, newServiceTypeID);
            insertStmt.setString(2, serviceType);
            insertStmt.executeUpdate();
            return newServiceTypeID; //dpt ID baru
        }
    }
    
    //bikin service type id
    private String generateServiceTypeID(Connection conn) throws SQLException {
        String query = "SELECT COUNT(*) AS count FROM msservicetype";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        int count = 0;
        if (rs.next()) {
            count = rs.getInt("count");
        }
        return String.format("ST%03d", count + 1); // Format ID menjadi ST001, ST002, dst.
    }
    
  //bikin service id
    private String generateServiceID(Connection conn) throws SQLException {
        String query = "SELECT COUNT(*) AS count FROM msservice";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        int count = 0;
        if (rs.next()) {
            count = rs.getInt("count");
        }
        return String.format("SV%03d", count + 1); // Format ID menjadi SV001, SV002, dst.
    }

    //method validasi kalo service name nya udh ada apa blm
    private boolean isServiceNameExist(String serviceName) {
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn != null) {
                String query = "SELECT ServiceName FROM msservice WHERE ServiceName = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, serviceName);
                ResultSet rs = stmt.executeQuery();
                return rs.next(); // Mengembalikan true jika service name sudah ada
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private String generateNewServiceID(Connection conn) throws SQLException {
        String query = "SELECT COUNT(*) AS count FROM msservice";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        int count = 0;
        if (rs.next()) {
            count = rs.getInt("count");
        }
        return String.format("SV%03d", count + 1); // Format ID menjadi SV001, SV002, dst.
    }
    
    //reset
    private void resetFields() {
        tfServiceName.clear();
        cbServiceType.setValue(null);
        tfServicePrice.clear();
        tfServiceDuration.clear();
    }

    public ServiceManagementPage(String username, String userRole) {
        this.username = username;
        this.userRole = userRole;
    }


    private void layout() {
        AdminNavigationBar adminNavBar = new AdminNavigationBar(username); // Admin Navigation Bar

        gp = new GridPane();
        gp.setAlignment(Pos.TOP_LEFT);
        gp.setPadding(new Insets(20));
        gp.setHgap(10);
        gp.setVgap(10);

        
        gp.add(lblServiceManagement, 0, 0);
        gp.add(lblServiceList, 0, 1);
        gp.add(table, 0, 2, 5, 10);

        
        gp.add(lblServiceName, 7, 2);
        gp.add(tfServiceName, 7, 3);

        gp.add(lblServiceType, 7, 4);
        gp.add(cbServiceType, 7, 5);

        gp.add(lblServicePrice, 7, 6);
        gp.add(tfServicePrice, 7, 7);

        gp.add(lblServiceDuration, 7, 8);
        gp.add(tfServiceDuration, 7, 9);

        
        VBox buttonBox = new VBox(10); // Jarak antar tombol
        buttonBox.setAlignment(Pos.TOP_CENTER);
        buttonBox.setPadding(new Insets(10, 0, 0, 0));

        //biar rapih aja
        btnAdd.setPrefWidth(250);
        btnUpdate.setPrefWidth(250);
        btnDelete.setPrefWidth(250);

        
        buttonBox.getChildren().addAll(btnAdd, btnUpdate, btnDelete);

        
        gp.add(buttonBox, 7, 10); 

        root = new BorderPane();
        root.setTop(adminNavBar.getMenuBar()); 
        root.setCenter(gp);

        scene = new Scene(root, 1000, 550);
    }
    


    //load data dr database
    private void loadServiceData() {
        serviceData = new Vector<>();
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn != null) {
            	String query = "SELECT s.ServiceID, st.ServiceTypeName, s.ServiceName, s.ServicePrice, s.ServiceDuration " +
                        "FROM msservice s " +
                        "JOIN msservicetype st ON s.ServiceTypeID = st.ServiceTypeID";

                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    String id = rs.getString("ServiceID");
                    String type = rs.getString("ServiceTypeName");
                    String name = rs.getString("ServiceName");
                    double price = rs.getDouble("ServicePrice");
                    int duration = rs.getInt("ServiceDuration");

                    serviceData.add(new ServiceManagement(id, type, name, price, duration));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to load service data: " + e.getMessage());
        }
    }

    private void populateTableView() {
        table.getItems().clear();
        table.getItems().addAll(serviceData);
    }

    private void populateServiceTypeComboBox() {
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn != null) {
                String query = "SELECT ServiceTypeName FROM msservicetype";
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    cbServiceType.getItems().add(rs.getString("ServiceTypeName"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to load service types: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
