package view;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

public class UserNavigationBar {
    private MenuBar menuBar;
    private String username; 

    public UserNavigationBar(String username) {
        this.username = username;
        menuBar = new MenuBar();
        Menu menu = new Menu("Menu");

        // Menu untuk User
        MenuItem reserveService = new MenuItem("Reserve Service");
        MenuItem customerReservation = new MenuItem("Customer Reservation");
        MenuItem logOut = new MenuItem("Log Out");

        menu.getItems().addAll(reserveService, customerReservation, logOut);
        menuBar.getMenus().add(menu);

        // Event Handler untuk Log Out
        logOut.setOnAction(event -> logOut());

        // Event Handler untuk navigasi ke Reserve Service Page
        reserveService.setOnAction(event -> navigateToReserveService());

        // Event Handler untuk navigasi ke Customer Reservation Page
        customerReservation.setOnAction(event -> navigateToCustomerReservation());
    }

    // kalo mencet customer reservation di nav bar, bakal di arahin ke CustomerReservationPage
    private void navigateToCustomerReservation() {
        Stage primaryStage = (Stage) menuBar.getScene().getWindow();
        CustomerReservationPage customerReservationPage = new CustomerReservationPage(username);
        try {
            customerReservationPage.start(primaryStage); // Navigasi ke halaman Customer Reservation
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //kalo mencet reserve service di nav bar, bakal di arahin ke ReserveServicePage
    private void navigateToReserveService() {
        Stage primaryStage = (Stage) menuBar.getScene().getWindow();
        ReserveServicePage reserveServicePage = new ReserveServicePage(username);
        try {
            reserveServicePage.start(primaryStage); // Navigasi ke halaman Reserve Service
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // klo pencet log out di nav bar, bakal ke log out balik ke login page
    private void logOut() {
        Stage primaryStage = (Stage) menuBar.getScene().getWindow();
        main.Main mainApp = new main.Main();
        try {
            mainApp.start(primaryStage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public MenuBar getMenuBar() {
        return menuBar;
    }
}
