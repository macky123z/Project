package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.User;
import view.ServiceManagementPage;
import view.ReservationManagementPage;
import view.ReserveServicePage;

public class Main extends Application implements EventHandler<ActionEvent> {
    Scene scene;
    GridPane gp;
    TextField tfEmail;
    PasswordField pfPassword;
    Button btnLogin;
    Hyperlink hypRegister;
    User loggedInUser; // buat nyimpen nama user yg lgi log in

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        initialize(primaryStage);
        layout();

        primaryStage.setTitle("Login - KingsHcut");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void initialize(Stage primaryStage) {
        gp = new GridPane();

        Label lblLoginTitle = new Label("Login");
        lblLoginTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Label lblEmail = new Label("Email:");
        tfEmail = new TextField();
        tfEmail.setPromptText("Enter your email");

        Label lblPassword = new Label("Password:");
        pfPassword = new PasswordField();
        pfPassword.setPromptText("Enter your password");

        btnLogin = new Button("Login");
        btnLogin.setOnAction(this);

        hypRegister = new Hyperlink("Don't have an account? Register here!");
        hypRegister.setOnAction(event -> {
            Register registerPage = new Register();
            Scene registerScene = registerPage.getScene(primaryStage, scene);
            primaryStage.setScene(registerScene);
        });
    }

    private void layout() {
        scene = new Scene(gp, 800, 500);

        gp.setAlignment(Pos.CENTER);
        gp.setPadding(new Insets(20));
        gp.setHgap(10);
        gp.setVgap(10);

        Label lblLoginTitle = new Label("Login");
        lblLoginTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Label lblEmail = new Label("Email:");
        tfEmail.setPrefWidth(300);

        Label lblPassword = new Label("Password:");
        pfPassword.setPrefWidth(300);

        gp.add(lblLoginTitle, 0, 0, 2, 1);
        gp.add(lblEmail, 0, 1);
        gp.add(tfEmail, 1, 1);
        gp.add(lblPassword, 0, 2);
        gp.add(pfPassword, 1, 2);
        gp.add(btnLogin, 1, 3);
        gp.add(hypRegister, 1, 4);

        GridPane.setHalignment(lblLoginTitle, HPos.CENTER);
        GridPane.setHalignment(btnLogin, HPos.CENTER);
        GridPane.setHalignment(hypRegister, HPos.CENTER);
    }

    @Override
    public void handle(ActionEvent event) {
        if (event.getSource() == btnLogin) {
            String email = tfEmail.getText().trim();
            String password = pfPassword.getText();

            if (email.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Validation Error", "Email cannot be empty!");
                return;
            }
            
            
            if (password.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Validation Error", "Password cannot be empty!");
                return;
            }

            User user = validateLogin(email, password);
            if (user != null) {
                loggedInUser = user; // nyimpen nama user yg lagi log in
                Stage primaryStage = (Stage) btnLogin.getScene().getWindow();

                try {
                    if ("Admin".equalsIgnoreCase(user.getRole())) {
                        // kalo role nya admin, pas login bakal lgsg redirecr ke reservation management page
                        ReservationManagementPage reservationManagementPage = new ReservationManagementPage(user.getRole());
                        reservationManagementPage.start(primaryStage);
                    } else {
                        // kalo role nya user, pas login lgsg redirect ke reserve service page
                        ReserveServicePage reserveServicePage = new ReserveServicePage(user.getUsername());
                        reserveServicePage.start(primaryStage);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to open the appropriate page.");
                }
            }
        }
    }
    
    //validasi login
    private User validateLogin(String email, String password) {
        try (Connection conn = DatabaseConnect.getConnection()) {
            String query = "SELECT UserID, Username, UserRole FROM msuser WHERE UserEmail = ? AND UserPassword = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String userID = rs.getString("UserID");
                String username = rs.getString("Username");
                String role = rs.getString("UserRole");

                showAlert(Alert.AlertType.INFORMATION, "Login Success", "Welcome, " + username + "!");
                return new User(userID, username, email, role);
            } else {
                showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid email or password.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error connecting to the database.");
        }
        return null;
    }
    
    //method template alert
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
