package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

//template konek ke database ini pokoknya
public class DatabaseConnect {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/KingsHcut"; //
    private static final String DB_USER = "root"; 
    private static final String DB_PASSWORD = ""; 

    public ResultSet rs;
	public ResultSetMetaData rsm;
	
	private Connection con;
	private Statement st;
	
    
    public static Connection getConnection() {
        try {
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Berhasil konek ke database!");
            return conn;
        } catch (SQLException e) {
            System.out.println("gagal konek ke database");
            e.printStackTrace();
            return null;
        }
    }

    public static void closeConnection(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
                System.out.println("koneksi ke database di close");
            }
        } catch (SQLException e) {
            System.out.println("error close koneksi ke database");
            e.printStackTrace();
        }
    }
    
 // untuk mereturn data
 	public ResultSet execQuery(String query) {
 		try {
 			rs = st.executeQuery(query);
 			rsm = rs.getMetaData();
 		} catch (SQLException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
 		return rs;
 	}
 	
 	public void execUpdate(String query) {
 		try {
 			st.executeUpdate(query);
 		} catch (SQLException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
 	}
}
