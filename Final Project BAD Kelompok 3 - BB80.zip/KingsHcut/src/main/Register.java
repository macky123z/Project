package main;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Register {
	
	//initialize sama layout di gabung jd 1 biar langsung
    public Scene getScene(Stage primaryStage, Scene loginScene) {
        GridPane gp = new GridPane();
        gp.setAlignment(Pos.CENTER);
        gp.setPadding(new Insets(20));
        gp.setHgap(10);
        gp.setVgap(5);

        Label lblRegisterTitle = new Label("Register");
        lblRegisterTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        GridPane.setHalignment(lblRegisterTitle, HPos.CENTER);

        Label lblUsername = new Label("Username:");
        TextField tfUsername = new TextField();
        tfUsername.setPromptText("Input your username here");

        Label lblEmail = new Label("Email:");
        TextField tfEmail = new TextField();
        tfEmail.setPromptText("Input your email here");

        Label lblPassword = new Label("Password:");
        PasswordField pfPassword = new PasswordField();
        pfPassword.setPromptText("Input your password here");

        Label lblConfirmPassword = new Label("Confirm Password:");
        PasswordField pfConfirmPassword = new PasswordField();
        pfConfirmPassword.setPromptText("Confirm your password here");

        Label lblPhoneNumber = new Label("Phone Number:");
        TextField tfPhoneNumber = new TextField();
        tfPhoneNumber.setPromptText("Input your phone number here");

        Label lblGender = new Label("Gender:");
        ToggleGroup genderGroup = new ToggleGroup();
        RadioButton rbMale = new RadioButton("Male");
        RadioButton rbFemale = new RadioButton("Female");
        rbMale.setToggleGroup(genderGroup);
        rbFemale.setToggleGroup(genderGroup);

        Button btnRegister = new Button("Register");
        Hyperlink hypLogin = new Hyperlink("Already have an account? Click here to login!");

        // layout 
        gp.add(lblRegisterTitle, 0, 0, 2, 1);
        gp.add(lblUsername, 0, 1, 2, 1);
        gp.add(tfUsername, 0, 2, 2, 1);
        gp.add(lblEmail, 0, 3, 2, 1);
        gp.add(tfEmail, 0, 4, 2, 1);
        gp.add(lblPassword, 0, 5, 2, 1);
        gp.add(pfPassword, 0, 6, 2, 1);
        gp.add(lblConfirmPassword, 0, 7, 2, 1);
        gp.add(pfConfirmPassword, 0, 8, 2, 1);
        gp.add(lblPhoneNumber, 0, 9, 2, 1);
        gp.add(tfPhoneNumber, 0, 10, 2, 1);
        gp.add(lblGender, 0, 11, 2, 1);
        gp.add(rbMale, 0, 12);
        gp.add(rbFemale, 1, 12);
        gp.add(btnRegister, 0, 13, 2, 1);
        gp.add(hypLogin, 0, 14, 2, 1);

        GridPane.setHalignment(btnRegister, HPos.CENTER);
        GridPane.setHalignment(hypLogin, HPos.CENTER);

        double textFieldWidth = 400;
        tfUsername.setPrefWidth(textFieldWidth);
        tfEmail.setPrefWidth(textFieldWidth);
        pfPassword.setPrefWidth(textFieldWidth);
        pfConfirmPassword.setPrefWidth(textFieldWidth);
        tfPhoneNumber.setPrefWidth(textFieldWidth);

        btnRegister.setOnAction(event -> {
            String username = tfUsername.getText().trim();
            String email = tfEmail.getText().trim();
            String password = pfPassword.getText();
            String confirmPassword = pfConfirmPassword.getText();
            String phoneNumber = tfPhoneNumber.getText().trim();
            String gender = rbMale.isSelected() ? "Male" : rbFemale.isSelected() ? "Female" : "";
            
            
            //validasi + alert
            if (username.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Register Error", "Username cannot be empty");
                return;
            }
            
            if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || phoneNumber.isEmpty() || gender.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Register Error", "All fields must be filled!");
                return;
            }
            
            

            if (username.length() < 5 || username.length() > 30) {
                showAlert(Alert.AlertType.ERROR, "Register Error", "Username must be 5-30 characters");
                return;
            }

            if (!email.endsWith("@gmail.com")) {
                showAlert(Alert.AlertType.ERROR, "Register Error", "Email must end with @gmail.com!");
                return;
            }
            
            if (isEmailExists(email)) {
                showAlert(Alert.AlertType.ERROR, "Register Error", "Email already been used!");
                return;
            }

            if (!password.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,15}$")) {
                showAlert(Alert.AlertType.ERROR, "Register Error", "Password must be 8-15 characters and alphanumeric!");
                return;
            }

            if (!password.equals(confirmPassword)) {
                showAlert(Alert.AlertType.ERROR, "Register Error", "Passwords must be the same as confirm password!");
                return;
            }

            if (phoneNumber.length() < 9 || phoneNumber.length() > 13 || !phoneNumber.startsWith("62")) {
                showAlert(Alert.AlertType.ERROR, "Register Error", "Phone number must start with '62' and be 9-13 characters long!");
                return;
            }
            
            if (phoneNumber.startsWith("62")) {
                phoneNumber = phoneNumber.replaceFirst("^62", "0");
            }

            if (isPhoneExists(phoneNumber)) {
                showAlert(Alert.AlertType.ERROR, "Register Error", "Phone number has already been used!");
                return;
            }

            String role = username.toLowerCase().contains("admin") ? "Admin" : "User";

            if (saveToDatabase(username, email, password, phoneNumber, gender, role)) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Registration successful!");
                primaryStage.setScene(loginScene);
            } else {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to register user!");
            }
        });

        hypLogin.setOnAction(event -> primaryStage.setScene(loginScene));

        return new Scene(gp, 800, 500);
    }
    
    //masukin data ke database msuser
    private boolean saveToDatabase(String username, String email, String password, String phoneNumber, String gender, String role) {
        String userID = generateUserID();
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Database connection failed!");
                return false;
            }
            String query = "INSERT INTO msuser (UserID, Username, UserPassword, UserEmail, UserPhoneNumber, UserGender, UserRole) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, userID);
            stmt.setString(2, username);
            stmt.setString(3, password);
            stmt.setString(4, email);
            stmt.setString(5, phoneNumber);
            stmt.setString(6, gender);
            stmt.setString(7, role);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    //validasi email org yg register ada di database apa ngga
    private boolean isEmailExists(String email) {
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Database connection failed!");
                return true; // Default true untuk mencegah registrasi
            }
            String query = "SELECT COUNT(*) FROM msuser WHERE UserEmail = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return true;
        }
    }
    
    //sama aja klo ini no hp nya
    private boolean isPhoneExists(String phoneNumber) {
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Database connection failed!");
                return true;
            }
            String query = "SELECT COUNT(*) FROM msuser WHERE UserPhoneNumber = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, phoneNumber);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return true;
        }
    }

    //bikin user id biar pas di input match sama validasi userid di databasenya
    private String generateUserID() {
        String userID = "US001";
        try (Connection conn = DatabaseConnect.getConnection()) {
            if (conn == null) {
                return userID;
            }
            String query = "SELECT UserID FROM msuser ORDER BY UserID DESC LIMIT 1";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String lastID = rs.getString("UserID");
                int num = Integer.parseInt(lastID.substring(2)) + 1;
                userID = String.format("US%03d", num);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userID;
    }
    
    //template alert 
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
