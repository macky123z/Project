module KingsHcut {
	opens main;
	opens model;
	opens view;
	
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.fxml;
	requires java.sql;
	requires javafx.base;
	requires jfxtras.labs;
	
	
}