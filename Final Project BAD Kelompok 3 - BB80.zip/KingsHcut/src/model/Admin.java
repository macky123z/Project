package model;
//OOP atribut admin
public class Admin {
    private String adminID;
    private String username;
    private String email;

    public Admin(String adminID, String username, String email) {
        this.adminID = adminID;
        this.username = username;
        this.email = email;
    }

    public String getAdminID() {
        return adminID;
    }

    public void setAdminID(String adminID) {
        this.adminID = adminID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
}

  
   
