package model;
//OOP atribut user
public class User {
    private String userID;
    private String username;
    private String role;
    private String email;

    public User(String userID, String username, String email, String role) {
        this.userID = userID;
        this.username = username;
        this.email = email;
        this.role = role;
    }

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


 
}
