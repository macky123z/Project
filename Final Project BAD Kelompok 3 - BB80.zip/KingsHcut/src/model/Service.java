package model;
//OOP atribut service
public class Service {
    private String serviceId;
    private String serviceName;
    private double price;
    private int duration;

    public Service(String id, String serviceName, double price, int duration) {
        super();
        this.serviceId = id;
        this.serviceName = serviceName;
        this.price = price;
        this.duration = duration;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
}
