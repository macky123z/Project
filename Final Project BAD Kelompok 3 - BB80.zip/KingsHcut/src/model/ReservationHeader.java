package model;
//OOP atribut reservation header
public class ReservationHeader {
    private String reservationID;
    private String reservationDate;
    private String startReservationTime;
    private String endReservationTime;
    private String reservationStatus;

    public ReservationHeader(String reservationID, String reservationDate, String startReservationTime, String endReservationTime, String reservationStatus) {
        this.reservationID = reservationID;
        this.reservationDate = reservationDate;
        this.startReservationTime = startReservationTime;
        this.endReservationTime = endReservationTime;
        this.reservationStatus = reservationStatus;
    }

    public String getReservationID() {
        return reservationID;
    }

    public void setReservationID(String reservationID) {
        this.reservationID = reservationID;
    }

    public String getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(String reservationDate) {
        this.reservationDate = reservationDate;
    }

    public String getStartReservationTime() {
        return startReservationTime;
    }

    public void setStartReservationTime(String startReservationTime) {
        this.startReservationTime = startReservationTime;
    }

    public String getEndReservationTime() {
        return endReservationTime;
    }

    public void setEndReservationTime(String endReservationTime) {
        this.endReservationTime = endReservationTime;
    }

    public String getReservationStatus() {
        return reservationStatus;
    }

    public void setReservationStatus(String reservationStatus) {
        this.reservationStatus = reservationStatus;
    }
}
